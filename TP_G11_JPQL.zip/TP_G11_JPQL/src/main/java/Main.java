import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        // 1. Iniciar el contenedor de JPA mediante Persistence.createEntityManagerFactory y obtener EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            // 2. Iniciar una transacción
            em.getTransaction().begin();

            // 3. Instanciar los objetos necesarios (Catálogos previos)
            // Primero creamos y guardamos el Usuario, PuntoVenta, Articulo, etc. 
            // Esto es necesario para que la Factura no dé error por relaciones faltantes.

            Usuario usuario = new Usuario();
            usuario.setUsuario("jperez");
            usuario.setClave("123456");
            usuario.setNombre("Juan");
            usuario.setApellido("Perez");
            em.persist(usuario); // Guardamos en BD

            PuntoVenta puntoVenta = new PuntoVenta();
            puntoVenta.setNumero(1);
            puntoVenta.setDescripcion("Sucursal Principal");
            puntoVenta.setTipoEmision("Factura Electronica");
            puntoVenta.setDomicilioComercial("Av. Siempreviva 742");
            puntoVenta.setFechaAlta(new Date()); // Campo obligatorio por AuditoriaApp
            puntoVenta.setUsuarioCarga(usuario); // ***
            puntoVenta.setFechaModificacion(new Date()); //***
            puntoVenta.setUsuarioModificacion(usuario); //***
            em.persist(puntoVenta); // Guardo en DB

            ListaPrecio listaP = new ListaPrecio();
            listaP.setCodigo("LP-01");
            listaP.setDenominacion("Lista General");
            listaP.setFechaAlta(new Date());
            listaP.setUsuarioCarga(usuario);
            listaP.setFechaModificacion(new Date());
            listaP.setUsuarioModificacion(usuario);
            em.persist(listaP);

            Articulo articulo = new Articulo();
            articulo.setCodigo("ART-001");
            articulo.setDenominacion("Monitor 24 Pulgadas");
            articulo.setFechaAlta(new Date());
            articulo.setUsuarioCarga(usuario);
            articulo.setFechaModificacion(new Date());
            articulo.setUsuarioModificacion(usuario);
            em.persist(articulo);

            ListaPrecioArticulo precioArticulo = new ListaPrecioArticulo();
            precioArticulo.setPrecioVenta(150000.0);
            precioArticulo.setArticulo(articulo);
            precioArticulo.setListaPrecio(listaP);
            precioArticulo.setFechaAlta(new Date());
            precioArticulo.setUsuarioCarga(usuario);
            precioArticulo.setFechaModificacion(new Date());
            precioArticulo.setUsuarioModificacion(usuario);
            em.persist(precioArticulo);

            // Creamos los nuevos objetos requeridos por la actualización del TP
            CondicionIva condicionIva = new CondicionIva();
            condicionIva.setCodigoAfip(1);
            condicionIva.setDenominacion("Responsable Inscripto");
            condicionIva.setFechaAlta(new Date());
            condicionIva.setUsuarioCarga(usuario);
            condicionIva.setFechaModificacion(new Date());
            condicionIva.setUsuarioModificacion(usuario);
            em.persist(condicionIva);

            TipoMoneda tipoMoneda = new TipoMoneda();
            tipoMoneda.setCodigoAfip("PES");
            tipoMoneda.setDenominacion("Pesos Argentinos");
            tipoMoneda.setSimbolo("$");
            tipoMoneda.setFechaAlta(new Date());
            tipoMoneda.setUsuarioCarga(usuario);
            tipoMoneda.setFechaModificacion(new Date());
            tipoMoneda.setUsuarioModificacion(usuario);
            em.persist(tipoMoneda);

            // 4. Crear una cabecera de FacturaVenta

            FacturaVenta facturaVenta = new FacturaVenta();
            facturaVenta.setNumero(10001L);
            facturaVenta.setFechaEmision(new Date());
            facturaVenta.setImporteTotal(150000.0);
            facturaVenta.setEstado("EMITIDA");
            facturaVenta.setPuntoVenta(puntoVenta);
            facturaVenta.setCondicionIva(condicionIva);
            facturaVenta.setTipoMoneda(tipoMoneda);

            // Campos de auditoría obligatorios heredados

            facturaVenta.setFechaAlta(new Date());
            facturaVenta.setUsuarioCarga(usuario);
            facturaVenta.setFechaModificacion(new Date());
            facturaVenta.setUsuarioModificacion(usuario);

            // Inicializar la lista de detalles si es null

            if (facturaVenta.getDetalles() == null) {
                facturaVenta.setDetalles(new ArrayList<>());
            }

            // Crear un ítem (FacturaVentaDetalle)

            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle();
            detalle1.setCantidad(1);
            detalle1.setPrecioUnitario(150000.0);
            detalle1.setImporteSubtotal(150000.0);
            detalle1.setDescripcion("Monitor 24 Pulgadas Gamer");
            detalle1.setListaPrecioArticulo(precioArticulo);

            // ASOCIACIÓN BIDIRECCIONAL (La clave del ejercicio)
            // A) Le decimos al detalle quién es su padre (la factura)
            detalle1.setFactura(facturaVenta);
            // B) Le decimos a la factura que agregue a su hijo (el detalle)
            facturaVenta.getDetalles().add(detalle1);

            // 5. REQUISITO CLAVE: Persistir únicamente el objeto cabecera

            System.out.println("Guardando FacturaVenta...");
            em.persist(facturaVenta);
            // Como FacturaVenta tiene @OneToMany(cascade = CascadeType.ALL),
            // Hibernate detecta el 'detalle1' y le hace INSERT en la base de datos automáticamente.

            // 6. Finalizar la transacción
            em.getTransaction().commit();
            System.out.println("¡Transacción Exitosa! Factura y detalles insertados automáticamente en cascada.");


            System.out.println("   TRABAJO PRÁCTICO GRUPAL: CONSULTAS JPQL");

            System.out.println("\n--- 1. Consulta de Entidades Completas ---");
            String jpql1 = "SELECT f FROM FacturaVenta f";
            List<FacturaVenta> facturas1 = em.createQuery(jpql1, FacturaVenta.class).getResultList();
            System.out.println("Facturas totales encontradas: " + facturas1.size());

            System.out.println("\n--- 2. Proyección de Atributos Específicos ---");
            String jpql2 = "SELECT f.numero, f.fechaEmision, f.importeTotal FROM FacturaVenta f";
            List<Object[]> resultados2 = em.createQuery(jpql2, Object[].class).getResultList();
            for (Object[] r : resultados2) {
                System.out.println("Nro: " + r[0] + " | Fecha: " + r[1] + " | Total: $" + r[2]);
            }

            System.out.println("\n--- 3. Filtrado por Igualdad (WHERE) ---");
            String jpql3 = "SELECT a FROM Articulo a WHERE a.rubro.denominacion = :rubro";
            List<Articulo> articulos3 = em.createQuery(jpql3, Articulo.class)
                    .setParameter("rubro", "Electrónica")
                    .getResultList();
            System.out.println("Artículos de Electrónica: " + articulos3.size());

            System.out.println("\n--- 4. Filtrado por Rango de Fechas (BETWEEN) ---");
            String jpql4 = "SELECT f FROM FacturaVenta f WHERE f.fechaEmision BETWEEN :inicio AND :fin";
            List<FacturaVenta> facturas4 = em.createQuery(jpql4, FacturaVenta.class)
                    .setParameter("inicio", new Date(100, 0, 1))
                    .setParameter("fin", new Date(200, 0, 1))
                    .getResultList();
            System.out.println("Facturas en rango de fechas: " + facturas4.size());

            System.out.println("\n--- 5. Condicionales Complejos y Verificación de Nulos ---");
            String jpql5 = "SELECT f FROM FacturaVenta f WHERE f.estado = 'EMITIDA' AND f.importeTotal > 10000 AND f.fechaAnulacion IS NULL";
            List<FacturaVenta> facturas5 = em.createQuery(jpql5, FacturaVenta.class).getResultList();
            System.out.println("Facturas 'EMITIDA' mayores a $10000: " + facturas5.size());

            System.out.println("\n--- 6. Búsqueda por Patrón de Texto (LIKE y LOWER) ---");
            String jpql6 = "SELECT c FROM Cliente c WHERE LOWER(c.denominacion) LIKE LOWER(CONCAT('%', :texto, '%')) OR c.cuitCuil LIKE '20-%'";
            List<Cliente> clientes6 = em.createQuery(jpql6, Cliente.class)
                    .setParameter("texto", "García")
                    .getResultList();
            System.out.println("Clientes encontrados (García o 20-...): " + clientes6.size());

            System.out.println("\n--- 7. Valores Distintos y Ordenamiento ---");
            String jpql7 = "SELECT DISTINCT f.estado FROM FacturaVenta f ORDER BY f.estado ASC";
            List<String> estados7 = em.createQuery(jpql7, String.class).getResultList();
            System.out.println("Estados sin duplicados ordenados: " + estados7);

            System.out.println("\n--- 8. Funciones de Agregación Simples ---");
            String jpql8 = "SELECT COUNT(f), SUM(f.importeTotal), AVG(f.importeTotal) FROM FacturaVenta f";
            Object[] agregaciones8 = (Object[]) em.createQuery(jpql8).getSingleResult();
            System.out.println("Cantidad Facturas: " + agregaciones8[0] + " | Suma: $" + agregaciones8[1] + " | Promedio: $" + agregaciones8[2]);

            System.out.println("\n--- 9. Operador de Inclusión (IN) ---");
            String jpql9 = "SELECT p FROM PuntoVenta p WHERE p.numero IN :numeros";
            List<PuntoVenta> puntos9 = em.createQuery(jpql9, PuntoVenta.class)
                    .setParameter("numeros", Arrays.asList(1, 2, 5))
                    .getResultList();
            System.out.println("Puntos de venta (1, 2, 5) encontrados: " + puntos9.size());

            System.out.println("\n--- 10. Navegación Implícita por Relaciones ---");
            String jpql10 = "SELECT f FROM FacturaVenta f WHERE f.usuarioCarga.usuario = :usr";
            List<FacturaVenta> facturas10 = em.createQuery(jpql10, FacturaVenta.class)
                    .setParameter("usr", "admin")
                    .getResultList();
            System.out.println("Facturas creadas por 'admin': " + facturas10.size());

            System.out.println("\n--- 11. Cláusula INNER JOIN Explícita ---");
            String jpql11 = "SELECT d FROM FacturaVentaDetalle d JOIN d.factura f WHERE f.puntoVenta.numero = :numPto";
            List<FacturaVentaDetalle> detalles11 = em.createQuery(jpql11, FacturaVentaDetalle.class)
                    .setParameter("numPto", 1)
                    .getResultList();
            System.out.println("Detalles del punto de venta 1: " + detalles11.size());

            System.out.println("\n--- 12. Cláusula LEFT JOIN ---");
            String jpql12 = "SELECT a.denominacion, m.denominacion FROM Articulo a LEFT JOIN a.marca m";
            List<Object[]> resultados12 = em.createQuery(jpql12, Object[].class).getResultList();
            System.out.println("Total de Artículos combinados con sus marcas: " + resultados12.size());

            System.out.println("\n--- 13. Navegación Multinivel con JOINs Combinados ---");
            String jpql13 = "SELECT DISTINCT f FROM FacturaVenta f JOIN f.detalles d JOIN d.listaPrecioArticulo lpa JOIN lpa.articulo a WHERE a.marca.denominacion = :marca";
            List<FacturaVenta> facturas13 = em.createQuery(jpql13, FacturaVenta.class)
                    .setParameter("marca", "Samsung")
                    .getResultList();
            System.out.println("Facturas que incluyen artículos Samsung: " + facturas13.size());

            System.out.println("\n--- 14. Subconsulta en Cláusula WHERE ---");
            String jpql14 = "SELECT f FROM FacturaVenta f WHERE f.importeTotal > (SELECT AVG(f2.importeTotal) FROM FacturaVenta f2)";
            List<FacturaVenta> facturas14 = em.createQuery(jpql14, FacturaVenta.class).getResultList();
            System.out.println("Facturas mayores al promedio general: " + facturas14.size());

            System.out.println("\n--- 15. Agrupamiento Básico (GROUP BY) ---");
            String jpql15 = "SELECT p.descripcion, COUNT(f), SUM(f.importeTotal) FROM FacturaVenta f JOIN f.puntoVenta p GROUP BY p.descripcion";
            List<Object[]> resultados15 = em.createQuery(jpql15, Object[].class).getResultList();
            for (Object[] r : resultados15) {
                System.out.println("Punto: " + r[0] + " | Cantidad Facturas: " + r[1] + " | Suma Total: $" + r[2]);
            }

            System.out.println("\n--- 16. Agrupamiento con Condicional de Grupo (HAVING) ---");
            String jpql16 = "SELECT u.usuario FROM FacturaVenta f JOIN f.usuarioCarga u GROUP BY u.usuario HAVING COUNT(f) > 5";
            List<String> usuarios16 = em.createQuery(jpql16, String.class).getResultList();
            System.out.println("Usuarios que hicieron más de 5 facturas: " + usuarios16);

            System.out.println("\n--- 17. Agrupamiento y Agregación sobre Entidades Relacionadas ---");
            String jpql17 = "SELECT m.denominacion, SUM(d.cantidad), SUM(d.importeSubtotal) FROM FacturaVentaDetalle d JOIN d.listaPrecioArticulo lpa JOIN lpa.articulo a JOIN a.marca m GROUP BY m.denominacion";
            List<Object[]> resultados17 = em.createQuery(jpql17, Object[].class).getResultList();
            for (Object[] r : resultados17) {
                System.out.println("Marca: " + r[0] + " | Unidades vendidas: " + r[1] + " | Subtotal Histórico: $" + r[2]);
            }

            System.out.println("\n--- 18. Subconsulta Correlacionada con EXISTS ---");
            String jpql18 = "SELECT m FROM Marca m WHERE EXISTS (SELECT d FROM FacturaVentaDetalle d WHERE d.listaPrecioArticulo.articulo.marca = m)";
            List<Marca> marcas18 = em.createQuery(jpql18, Marca.class).getResultList();
            System.out.println("Marcas que alguna vez fueron facturadas: " + marcas18.size());

            System.out.println("\n--- 19. Subconsulta Correlacionada con NOT EXISTS ---");
            String jpql19 = "SELECT a FROM Articulo a WHERE NOT EXISTS (SELECT d FROM FacturaVentaDetalle d WHERE d.listaPrecioArticulo.articulo = a)";
            List<Articulo> articulos19 = em.createQuery(jpql19, Articulo.class).getResultList();
            System.out.println("Artículos que JAMÁS fueron facturados: " + articulos19.size());

            System.out.println("\n--- 20. Proyección Condicional (CASE WHEN) ---");
            String jpql20 = "SELECT f.numero, f.importeTotal, CASE WHEN f.importeTotal > 50000 THEN 'ALTO VALOR' WHEN f.importeTotal BETWEEN 10000 AND 50000 THEN 'MEDIO VALOR' ELSE 'BAJO VALOR' END FROM FacturaVenta f ORDER BY f.importeTotal DESC";
            List<Object[]> resultados20 = em.createQuery(jpql20, Object[].class).getResultList();
            for (Object[] r : resultados20) {
                System.out.println("Nro Factura: " + r[0] + " | Total: $" + r[1] + " | Clasificación: " + r[2]);
            }




        } catch (Exception e) {
            // Si hay algún error (como un dato null), la transacción se cancela (rollback)
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("Ocurrió un error al intentar guardar en la base de datos:");
            e.printStackTrace();
        } finally {
            // 7. Cerrar el EntityManager y EntityManagerFactory
            em.close();
            emf.close();
            System.out.println("Conexiones a la base de datos cerradas.");
        }
    }
}